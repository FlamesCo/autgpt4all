import time
import requests

# Define the rate limits
RPM = 200
TPM = 10000

# Calculate the delay
delay_RPM = 60 / RPM
delay_TPM = 60 / TPM

def make_request(url, headers, data):
    # Add the delay before making the request
    time.sleep(max(delay_RPM, delay_TPM))
    # Make the request
    response = requests.post(url, headers=headers, data=data)
    return response

# TODO: Add the code to use make_request in the rate limit proxy